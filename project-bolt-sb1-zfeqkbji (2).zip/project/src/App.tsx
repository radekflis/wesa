import { useEffect } from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { Zap } from 'lucide-react';
import { useWorkspace } from './store/workspace';
import { useDataLoader } from './lib/hooks';
import { initGemini } from './gemini';
import { TopNavigation } from './components/TopNavigation';
import { LeftSidebar } from './components/LeftSidebar';
import { CenterWorkspace } from './components/CenterWorkspace';
import { RightSidebar } from './components/RightSidebar';
import { CommandPalette } from './components/CommandPalette';
import { WormholeOverlay } from './components/WormholeOverlay';
import { SettingsModal } from './components/SettingsModal';
import { Notification } from './components/Notification';

const LS_KEY = 'alaw_gemini_key';

export default function App() {
  const { leftOpen, rightOpen, setWormhole, wormholeOpen } = useWorkspace();
  const { loadAll } = useDataLoader();

  useEffect(() => {
    const key = localStorage.getItem(LS_KEY) ?? import.meta.env.VITE_GEMINI_API_KEY ?? '';
    if (key) initGemini(key);
    loadAll();
  }, []);

  return (
    <div className="h-screen flex flex-col bg-white overflow-hidden antialiased">
      <Notification />
      <CommandPalette />
      <WormholeOverlay />
      <SettingsModal />

      <TopNavigation />

      <div className="flex-1 overflow-hidden">
        <PanelGroup direction="horizontal" autoSaveId="alaw-layout">
          {leftOpen && (
            <>
              <Panel defaultSize={18} minSize={14} maxSize={28} order={1}>
                <LeftSidebar />
              </Panel>
              <PanelResizeHandle className="w-px bg-slate-100 hover:bg-teal-200 transition-colors data-[resize-handle-active]:bg-teal-300" />
            </>
          )}

          <Panel defaultSize={leftOpen && rightOpen ? 58 : leftOpen || rightOpen ? 72 : 100} minSize={40} order={2}>
            <CenterWorkspace />
          </Panel>

          {rightOpen && (
            <>
              <PanelResizeHandle className="w-px bg-slate-100 hover:bg-teal-200 transition-colors data-[resize-handle-active]:bg-teal-300" />
              <Panel defaultSize={24} minSize={18} maxSize={32} order={3}>
                <RightSidebar />
              </Panel>
            </>
          )}
        </PanelGroup>
      </div>

      {/* Wormhole FAB */}
      <button onClick={() => setWormhole(!wormholeOpen)}
        className={`fixed bottom-8 right-8 z-30 w-12 h-12 rounded-full flex items-center justify-center shadow-[0_8px_32px_-4px_rgba(0,0,0,0.12)] transition-all duration-300 ${
          wormholeOpen ? 'bg-teal-500 rotate-[135deg] scale-95' : 'bg-slate-900 hover:bg-slate-700 hover:scale-105'
        }`}>
        <Zap className="w-4 h-4 text-white" />
        {!wormholeOpen && <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-teal-400 rounded-full ring-2 ring-white animate-pulse" />}
      </button>
    </div>
  );
}
