import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseKey);

export interface DbDocument {
  id: string;
  name: string;
  file_type: string;
  file_size: number;
  folder_path: string;
  storage_path: string | null;
  content_text: string;
  tags: string[];
  created_at: string;
  updated_at: string;
}

export interface DbSource {
  id: string;
  document_id: string | null;
  label: string;
  source_text: string;
  source_url: string | null;
  page_number: number | null;
  confidence: number;
  verified: boolean;
  created_at: string;
}

export async function uploadFile(file: File, folderPath: string): Promise<DbDocument | null> {
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storagePath = `uploads/${Date.now()}_${safeName}`;

  // 1. Insert record to DB first (this always works)
  const { data, error } = await supabase
    .from('documents')
    .insert({
      name: file.name,
      file_type: file.type || 'application/octet-stream',
      file_size: file.size,
      folder_path: folderPath,
      storage_path: null,
      tags: extractTags(file.name),
    })
    .select()
    .maybeSingle();

  if (error || !data) {
    console.error('DB insert error:', error?.message);
    return null;
  }

  // 2. Try storage upload in background, update record if successful
  try {
    const { error: uploadError } = await supabase.storage
      .from('documents')
      .upload(storagePath, file, { cacheControl: '3600', upsert: true });

    if (!uploadError) {
      await supabase.from('documents').update({ storage_path: storagePath }).eq('id', data.id);
      data.storage_path = storagePath;
    } else {
      console.warn('Storage upload failed (file saved to DB only):', uploadError.message);
    }
  } catch (e) {
    console.warn('Storage upload exception (file saved to DB only):', e);
  }

  return data;
}

export async function fetchDocuments(): Promise<DbDocument[]> {
  const { data, error } = await supabase
    .from('documents')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Fetch docs error:', error.message);
    return [];
  }
  return data ?? [];
}

export async function deleteDocument(id: string, storagePath: string | null): Promise<boolean> {
  if (storagePath) {
    await supabase.storage.from('documents').remove([storagePath]);
  }
  const { error } = await supabase.from('documents').delete().eq('id', id);
  if (error) {
    console.error('Delete error:', error.message);
    return false;
  }
  return true;
}

export async function updateDocument(id: string, updates: Partial<DbDocument>): Promise<boolean> {
  const { error } = await supabase.from('documents').update(updates).eq('id', id);
  return !error;
}

export async function fetchSources(documentId?: string): Promise<DbSource[]> {
  let query = supabase.from('sources').select('*').order('created_at', { ascending: false });
  if (documentId) query = query.eq('document_id', documentId);
  const { data, error } = await query;
  if (error) {
    console.error('Fetch sources error:', error.message);
    return [];
  }
  return data ?? [];
}

export async function addSource(source: Omit<DbSource, 'id' | 'created_at'>): Promise<DbSource | null> {
  const { data, error } = await supabase
    .from('sources')
    .insert(source)
    .select()
    .maybeSingle();
  if (error) {
    console.error('Add source error:', error.message);
    return null;
  }
  return data;
}

export async function deleteSource(id: string): Promise<boolean> {
  const { error } = await supabase.from('sources').delete().eq('id', id);
  return !error;
}

export function getFileUrl(storagePath: string): string {
  const { data } = supabase.storage.from('documents').getPublicUrl(storagePath);
  return data.publicUrl;
}

function extractTags(filename: string): string[] {
  const name = filename.replace(/\.[^.]+$/, '').toLowerCase();
  const words = name.split(/[_\-\s.]+/).filter(w => w.length > 2);
  return words.slice(0, 5);
}
