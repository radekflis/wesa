import { useRef, useCallback } from 'react';
import { useWorkspace } from '../store/workspace';
import { uploadFile, fetchDocuments, fetchSources } from '../supabase';

export function useUploader() {
  const { currentFolder, addDocument, setUploading, notify } = useWorkspace();
  const inputRef = useRef<HTMLInputElement>(null);

  const open = useCallback(() => inputRef.current?.click(), []);

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    const fileArr = Array.from(files);
    if (fileArr.length === 0) return;

    setUploading(true);
    notify(`Uploading ${fileArr.length} file${fileArr.length > 1 ? 's' : ''}...`);

    let success = 0;
    for (const file of fileArr) {
      const doc = await uploadFile(file, currentFolder);
      if (doc) { addDocument(doc); success++; }
    }

    setUploading(false);
    if (success > 0) notify(`${success} file${success > 1 ? 's' : ''} uploaded`);
    else notify('Upload failed. Check console.');
  }, [currentFolder, addDocument, setUploading, notify]);

  const onInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) handleFiles(e.target.files);
    e.target.value = '';
  }, [handleFiles]);

  return { inputRef, open, handleFiles, onInputChange };
}

export function useDataLoader() {
  const { setDocuments, setSources } = useWorkspace();

  const loadAll = useCallback(async () => {
    const [docs, srcs] = await Promise.all([fetchDocuments(), fetchSources()]);
    setDocuments(docs);
    setSources(srcs);
  }, [setDocuments, setSources]);

  return { loadAll };
}
