import { GoogleGenerativeAI, GenerativeModel } from '@google/generative-ai';

const SYSTEM_INSTRUCTION = `You are an elite AI orchestrator for the Adaptive Layered AI Workflowstation (ALAW). You specialize in advanced geology, quantitative finance, and corporate law. Analyze the provided context and extract structured insights, data tables, or summaries as requested. Keep responses concise and structured. When producing data tables, use tab-separated values with a header row. For summaries, use clear paragraphs. For extractions, use labelled fields. Avoid markdown symbols like # or ** — use plain text only.`;

let model: GenerativeModel | null = null;
let currentKey = '';

export function initGemini(apiKey: string) {
  if (!apiKey) { model = null; currentKey = ''; return; }
  if (apiKey === currentKey && model) return;
  const genAI = new GoogleGenerativeAI(apiKey);
  model = genAI.getGenerativeModel({
    model: 'gemini-1.5-flash',
    systemInstruction: SYSTEM_INSTRUCTION,
  });
  currentKey = apiKey;
}

export function isReady() {
  return model !== null && currentKey.length > 0;
}

export type StreamCallback = (chunk: string, done: boolean) => void;

export async function streamPrompt(
  prompt: string,
  onChunk: StreamCallback,
  onError: (msg: string) => void
) {
  if (!model) { onError('No API key configured. Open Settings to add your Gemini API key.'); return; }
  try {
    const result = await model.generateContentStream(prompt);
    for await (const chunk of result.stream) {
      const text = chunk.text();
      if (text) onChunk(text, false);
    }
    onChunk('', true);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('API_KEY_INVALID') || msg.includes('API key not valid')) {
      onError('Invalid API key. Please check your Gemini API key in Settings.');
    } else if (msg.includes('SAFETY')) {
      onError('Response blocked by safety filters. Try rephrasing your prompt.');
    } else if (msg.includes('quota') || msg.includes('429')) {
      onError('API quota exceeded. Please check your Gemini plan.');
    } else {
      onError(`Gemini error: ${msg}`);
    }
  }
}

export function buildWormholePrompt(fileName: string, fileType: string, documentContext: string): string {
  return `A file named "${fileName}" (${fileType}) was dropped into the ALAW Live Workspace. The current document context is:\n\n${documentContext}\n\nAnalyze this file drop in the context of the above document. Produce a concise structured summary block: what this file likely contains, what fields it would contribute to the valuation analysis, and list 3-5 key data points we would expect to extract from it. Format as plain paragraphs with labelled sections.`;
}

export function buildAiActionPrompt(action: string, text: string): string {
  const prompts: Record<string, string> = {
    Rephrase:  `Rephrase the following geological/financial text to be more precise and professional for a JORC-compliant technical report:\n\n"${text}"`,
    Summarise: `Produce a concise 2-sentence technical summary of the following text, suitable for an executive briefing:\n\n"${text}"`,
    Extract:   `Extract all structured data fields (measurements, grades, dates, entities, values) from the following text. Format as labelled lines: Field: Value\n\n"${text}"`,
    Translate: `Translate the following geological/financial text into formal German (Deutsch), preserving all technical terminology:\n\n"${text}"`,
  };
  return prompts[action] ?? `Apply "${action}" transformation to this text:\n\n"${text}"`;
}

export function buildSearchPrompt(query: string, documentContext: string): string {
  return `The user of the ALAW Workflowstation submitted this search/command: "${query}"\n\nCurrent document context:\n${documentContext}\n\nInterpret the intent and produce a structured, actionable response. If the query is a question, answer it directly. If it is a command (e.g., "summarise", "find", "calculate"), execute it against the document context. Keep the response under 200 words.`;
}
