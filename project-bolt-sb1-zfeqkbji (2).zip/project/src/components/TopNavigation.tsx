import {
  Cpu, Search, Command, Plus, Settings,
  PanelLeftOpen, PanelRightOpen, X, Upload,
  FileText, BarChart2, Map, Globe, Layers,
} from 'lucide-react';
import { useWorkspace } from '../store/workspace';
import { useUploader } from '../lib/hooks';
import { isReady } from '../gemini';

const TAB_ICONS: Record<string, typeof FileText> = {
  document: FileText,
  analysis: BarChart2,
  map: Map,
  dataset: Globe,
  report: Layers,
};

export function TopNavigation() {
  const {
    tabs, activeTabId, addTab, closeTab, setActiveTab,
    toggleLeft, toggleRight,
    setCommandPalette, setSettings, synced, uploading,
  } = useWorkspace();
  const { inputRef, open, onInputChange } = useUploader();

  const newTab = () => {
    const id = `tab-${Date.now()}`;
    addTab({ id, label: 'New Tab', type: 'document' });
  };

  return (
    <header className="h-[52px] flex items-stretch border-b border-slate-200/60 bg-white flex-shrink-0 relative z-20">
      <input ref={inputRef} type="file" multiple accept="*/*" className="hidden" onChange={onInputChange} />

      {/* Logo */}
      <div className="flex items-center gap-3 px-5 border-r border-slate-100 flex-shrink-0">
        <div className="w-8 h-8 rounded-xl bg-slate-900 flex items-center justify-center">
          <Cpu className="w-4 h-4 text-white" />
        </div>
        <div className="hidden md:block">
          <p className="text-[12px] font-bold text-slate-900 leading-none tracking-tight">ALAW</p>
          <p className="text-[9px] text-slate-400 leading-none mt-[3px] tracking-[0.12em] uppercase font-light">Workflowstation</p>
        </div>
      </div>

      {/* Sidebar toggle left */}
      <button onClick={toggleLeft}
        className="flex items-center justify-center w-9 border-r border-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors">
        <PanelLeftOpen className="w-3.5 h-3.5" />
      </button>

      {/* Tabs */}
      <div className="flex items-stretch flex-1 min-w-0 overflow-x-auto">
        {tabs.map(tab => {
          const Icon = TAB_ICONS[tab.type] ?? FileText;
          return (
            <div key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 border-r border-slate-100 cursor-pointer transition-colors relative min-w-0 ${
                tab.id === activeTabId ? 'bg-white' : 'bg-slate-50/30 hover:bg-slate-50'
              }`}>
              <Icon className="w-3 h-3 text-slate-400 flex-shrink-0" />
              <span className="text-[11px] font-medium text-slate-700 truncate max-w-[100px]">{tab.label}</span>
              {tabs.length > 1 && (
                <button onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                  className="p-0.5 rounded text-slate-300 hover:text-slate-500 transition-colors flex-shrink-0">
                  <X className="w-3 h-3" />
                </button>
              )}
              {tab.id === activeTabId && <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-slate-900" />}
            </div>
          );
        })}
        <button onClick={newTab}
          className="flex items-center justify-center w-9 border-r border-slate-100 text-slate-300 hover:text-slate-500 hover:bg-slate-50 transition-colors">
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Search */}
      <div className="flex items-center px-3 border-l border-slate-100">
        <button onClick={() => setCommandPalette(true)}
          className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-lg px-3.5 py-1.5 text-[12px] text-slate-400 w-44 transition-colors">
          <Search className="w-3.5 h-3.5" />
          <span className="flex-1 text-left font-light">Search...</span>
          <span className="text-[9px] bg-white border border-slate-100 px-1 py-0.5 rounded flex items-center gap-0.5 font-mono">
            <Command className="w-2.5 h-2.5" />K
          </span>
        </button>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1.5 px-3 border-l border-slate-100">
        <button onClick={open}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-700 text-white text-[11px] rounded-lg transition-colors font-medium">
          <Upload className="w-3 h-3" />
          <span className="hidden sm:inline">Upload</span>
        </button>

        {/* Sync indicator */}
        <div className="flex items-center gap-1.5 px-2">
          <div className={`w-2 h-2 rounded-full transition-colors ${
            uploading ? 'bg-amber-400 animate-pulse' :
            synced ? 'bg-emerald-400' : 'bg-slate-300'
          }`} />
          <span className="text-[10px] text-slate-400 hidden lg:inline font-light">
            {uploading ? 'Syncing' : isReady() ? 'AI Ready' : 'No key'}
          </span>
        </div>

        <button onClick={() => setSettings(true)}
          className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors">
          <Settings className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Sidebar toggle right */}
      <button onClick={toggleRight}
        className="flex items-center justify-center w-9 border-l border-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors">
        <PanelRightOpen className="w-3.5 h-3.5" />
      </button>
    </header>
  );
}
