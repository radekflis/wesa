import {
  Scan, Globe, BarChart2, Layers, Network, Truck,
  Activity, CheckCircle2, ExternalLink, Link, FileText, Info,
} from 'lucide-react';
import { useWorkspace } from '../store/workspace';
import { getFileUrl } from '../supabase';
import { isReady, streamPrompt } from '../gemini';

interface ToolModule {
  id: string;
  label: string;
  desc: string;
  icon: typeof Scan;
  status: 'ready' | 'active' | 'idle';
}

const TOOLS: ToolModule[] = [
  { id: 'ocr', label: 'OCR Extraction', desc: 'Extract text from images and scanned documents', icon: Scan, status: 'ready' },
  { id: 'geo', label: 'Geological Mapping', desc: 'Spatial analysis and resource visualization', icon: Globe, status: 'ready' },
  { id: 'valuation', label: 'Resource Estimation', desc: 'Mineral tonnage and grade modeling', icon: BarChart2, status: 'idle' },
  { id: 'chem', label: 'Chemical Composition', desc: 'Elemental and oxide analysis', icon: Layers, status: 'ready' },
  { id: 'transport', label: 'Transport Chain', desc: 'Logistics and supply route analysis', icon: Truck, status: 'idle' },
  { id: 'supply', label: 'Supply Chain Map', desc: 'End-to-end supply network', icon: Network, status: 'idle' },
];

function StatusBadge({ status }: { status: string }) {
  if (status === 'active') return <span className="flex items-center gap-1 text-[9px] font-medium text-emerald-600"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />Active</span>;
  if (status === 'ready') return <span className="flex items-center gap-1 text-[9px] font-medium text-sky-500"><span className="w-1.5 h-1.5 rounded-full bg-sky-400" />Ready</span>;
  return <span className="flex items-center gap-1 text-[9px] font-medium text-slate-400"><span className="w-1.5 h-1.5 rounded-full bg-slate-300" />Idle</span>;
}

export function RightSidebar() {
  const { sources, documents, selectedDocId, selectDocument, addBlock, notify } = useWorkspace();

  const selectedDoc = documents.find(d => d.id === selectedDocId);

  const handleToolClick = (tool: ToolModule) => {
    if (!isReady()) {
      notify('Add API key in Settings');
      return;
    }

    const ctx = selectedDoc ? `Active document: ${selectedDoc.name} (${selectedDoc.file_type})` : 'No active document';
    const blockId = `ai-${Date.now()}`;
    addBlock({ id: blockId, type: 'ai-stream', content: '', meta: tool.label, streaming: true });

    streamPrompt(
      `You are a ${tool.label} specialist. ${tool.desc}. Context: ${ctx}. Provide a brief analysis, summary of capabilities, and what data is needed to proceed.`,
      (chunk, done) => useWorkspace.getState().updateBlock(blockId, done ? { streaming: false } : { content: useWorkspace.getState().blocks.find(b => b.id === blockId)!.content + chunk }),
      (err) => useWorkspace.getState().updateBlock(blockId, { content: err, streaming: false, error: true })
    );
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="h-11 flex items-center px-4 border-b border-slate-100 flex-shrink-0">
        <span className="text-[11px] font-semibold text-slate-700 tracking-wide uppercase">Contextual Tools</span>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Tool modules */}
        <div className="p-3 space-y-1.5">
          {TOOLS.map(tool => (
            <button key={tool.id} onClick={() => handleToolClick(tool)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left group border border-transparent hover:border-slate-100">
              <div className="w-8 h-8 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center flex-shrink-0 group-hover:border-slate-200 transition-colors">
                <tool.icon className="w-3.5 h-3.5 text-slate-500" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-medium text-slate-700">{tool.label}</p>
                  <StatusBadge status={tool.status} />
                </div>
                <p className="text-[10px] text-slate-400 font-light truncate">{tool.desc}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Sources section */}
        <div className="border-t border-slate-100 mt-2">
          <div className="px-4 py-2.5 flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Sources</span>
            <span className="text-[10px] text-slate-300">{sources.length}</span>
          </div>

          {sources.length === 0 ? (
            <div className="px-4 py-6 text-center">
              <Link className="w-5 h-5 text-slate-200 mx-auto mb-2" />
              <p className="text-[11px] text-slate-400 font-light">No sources linked</p>
              <p className="text-[10px] text-slate-300 font-light mt-0.5">Select text to create source links</p>
            </div>
          ) : (
            <div className="px-3 pb-3 space-y-1">
              {sources.slice(0, 10).map(src => (
                <div key={src.id}
                  onClick={() => { if (src.document_id) selectDocument(src.document_id); }}
                  className="flex items-start gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer">
                  {src.verified
                    ? <CheckCircle2 className="w-3 h-3 text-emerald-500 mt-0.5 flex-shrink-0" />
                    : <Info className="w-3 h-3 text-amber-400 mt-0.5 flex-shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-medium text-slate-700 truncate">{src.label}</p>
                    <p className="text-[10px] text-slate-400 font-light truncate">{src.source_text}</p>
                  </div>
                  {src.confidence > 0 && (
                    <span className={`text-[9px] font-medium px-1.5 py-0.5 rounded ${
                      src.confidence >= 90 ? 'bg-emerald-50 text-emerald-600' :
                      src.confidence >= 70 ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-500'
                    }`}>{src.confidence}%</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active document info */}
        {selectedDoc && (
          <div className="border-t border-slate-100 px-4 py-3">
            <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2.5">Active Document</p>
            <div className="flex items-center gap-2 mb-2.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <p className="text-[11px] font-medium text-slate-700 truncate">{selectedDoc.name}</p>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[10px]">
              <span className="text-slate-400 font-light">Size</span>
              <span className="text-slate-600 text-right">{selectedDoc.file_size < 1048576 ? `${(selectedDoc.file_size / 1024).toFixed(1)} KB` : `${(selectedDoc.file_size / 1048576).toFixed(1)} MB`}</span>
              <span className="text-slate-400 font-light">Type</span>
              <span className="text-slate-600 text-right">{selectedDoc.file_type.split('/').pop()}</span>
              <span className="text-slate-400 font-light">Path</span>
              <span className="text-slate-600 text-right truncate">{selectedDoc.folder_path}</span>
            </div>
            {selectedDoc.storage_path && (
              <button onClick={() => { const url = getFileUrl(selectedDoc.storage_path!); window.open(url, '_blank'); }}
                className="mt-3 w-full flex items-center justify-center gap-1.5 py-2 border border-slate-100 rounded-lg text-[11px] text-slate-500 hover:bg-slate-50 hover:border-slate-200 transition-colors font-medium">
                <ExternalLink className="w-3 h-3" />Open File
              </button>
            )}
          </div>
        )}
      </div>

      {/* AI Status */}
      <div className="h-9 flex items-center justify-between px-4 border-t border-slate-100 flex-shrink-0 bg-slate-50/30">
        <div className="flex items-center gap-1.5">
          <Activity className="w-3 h-3 text-slate-400" />
          <span className="text-[10px] text-slate-400 font-light">Workflow Status</span>
        </div>
        {isReady()
          ? <span className="flex items-center gap-1 text-[10px] text-emerald-500"><span className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />AI Online</span>
          : <span className="text-[10px] text-slate-300">Offline</span>}
      </div>
    </div>
  );
}
