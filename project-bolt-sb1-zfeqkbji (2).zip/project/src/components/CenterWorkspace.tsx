import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, X, Sparkles, Loader2, AlertCircle,
  Hash, AlignLeft, Table2, Zap, Target, BookOpen, Wand2,
  RotateCcw,
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { useWorkspace, type DocBlock } from '../store/workspace';
import { uploadFile } from '../supabase';
import { isReady, streamPrompt, buildAiActionPrompt, buildWormholePrompt } from '../gemini';

function MetricCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex-1 min-w-[120px] bg-slate-50/60 border border-slate-100 rounded-xl px-4 py-3 hover:border-slate-200 transition-colors cursor-default">
      <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider mb-1">{label}</p>
      <p className="text-[18px] font-semibold text-slate-800 leading-none">{value}</p>
    </div>
  );
}

function BlockView({ block, onEdit, onDelete }: { block: DocBlock; onEdit: (content: string) => void; onDelete: () => void }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(block.content);

  useEffect(() => setVal(block.content), [block.content]);

  if (block.type === 'ai-stream') {
    return (
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}
        className={`rounded-xl border px-5 py-4 ${block.error ? 'border-rose-100 bg-rose-50/30' : 'border-teal-100/60 bg-teal-50/20'}`}>
        <div className="flex items-center gap-2 mb-2.5">
          {block.error ? <AlertCircle className="w-3.5 h-3.5 text-rose-400" /> : block.streaming ? <Loader2 className="w-3.5 h-3.5 text-teal-500 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-teal-500" />}
          <span className={`text-[10px] font-semibold uppercase tracking-wider ${block.error ? 'text-rose-500' : 'text-teal-600'}`}>
            {block.error ? 'Error' : block.streaming ? 'Generating...' : block.meta ?? 'AI Response'}
          </span>
          {!block.streaming && <button onClick={onDelete} className="ml-auto p-1 rounded text-slate-300 hover:text-rose-400 transition-colors"><X className="w-3 h-3" /></button>}
        </div>
        <p className={`text-[13px] leading-relaxed whitespace-pre-wrap font-light ${block.error ? 'text-rose-600' : 'text-slate-600'}`}>
          {block.content}{block.streaming && <span className="inline-block w-0.5 h-4 bg-teal-400 ml-0.5 animate-pulse align-middle" />}
        </p>
      </motion.div>
    );
  }

  if (block.type === 'metric') {
    const parts = block.content.split('|');
    const metrics: { label: string; value: string }[] = [];
    for (let i = 0; i < parts.length; i += 2) {
      if (parts[i + 1]) metrics.push({ label: parts[i], value: parts[i + 1] });
    }
    return (
      <div className="flex flex-wrap gap-3 group relative">
        {metrics.map((m, i) => <MetricCard key={i} label={m.label} value={m.value} />)}
        <button onClick={onDelete} className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 w-5 h-5 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-300 hover:text-rose-400 shadow-sm transition-all"><X className="w-3 h-3" /></button>
      </div>
    );
  }

  if (block.type === 'data-table') {
    const rows = block.content.split('\n').map(r => r.split('\t'));
    const [header, ...body] = rows;
    return (
      <div className="group relative">
        <div className="overflow-x-auto rounded-xl border border-slate-100">
          <table className="w-full text-[12px]">
            <thead><tr className="bg-slate-50/60 border-b border-slate-100">
              {header.map((h, i) => <th key={i} className="px-4 py-2.5 text-left font-semibold text-slate-500 text-[10px] uppercase tracking-wider">{h}</th>)}
            </tr></thead>
            <tbody>{body.map((row, ri) => (
              <tr key={ri} className="border-b border-slate-50 hover:bg-slate-50/40 transition-colors">
                {row.map((cell, ci) => (
                  <td key={ci} className="px-4 py-2.5 text-slate-600 font-light">{cell}</td>
                ))}
              </tr>
            ))}</tbody>
          </table>
        </div>
        <button onClick={onDelete} className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 w-5 h-5 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-300 hover:text-rose-400 shadow-sm transition-all"><X className="w-3 h-3" /></button>
      </div>
    );
  }

  if (block.type === 'annotation') {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="flex items-start gap-3 bg-amber-50/40 border border-amber-100/60 rounded-xl px-5 py-3.5 group relative">
        <AlertCircle className="w-3.5 h-3.5 text-amber-400 mt-0.5 flex-shrink-0" />
        <p className="text-[12px] text-amber-700/80 leading-relaxed font-light">{block.content}</p>
        <button onClick={onDelete} className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 w-5 h-5 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-300 hover:text-rose-400 shadow-sm transition-all"><X className="w-3 h-3" /></button>
      </motion.div>
    );
  }

  const cls = block.type === 'h1' ? 'text-[28px] font-semibold text-slate-900 leading-tight tracking-tight'
    : block.type === 'h2' ? 'text-[10px] font-semibold text-slate-400 uppercase tracking-[0.15em]'
    : block.type === 'h3' ? 'text-[16px] font-medium text-slate-700'
    : 'text-[14px] text-slate-600 leading-[1.8] font-light';

  if (editing) return (
    <textarea autoFocus value={val} onChange={e => setVal(e.target.value)}
      onBlur={() => { onEdit(val); setEditing(false); }}
      onKeyDown={e => { if (e.key === 'Escape') { setVal(block.content); setEditing(false); } }}
      className={`w-full bg-transparent resize-none focus:outline-none border-b border-teal-200 pb-2 ${cls}`}
      rows={block.type === 'para' ? 4 : 2} />
  );

  return (
    <div className="group relative cursor-text rounded-lg hover:bg-slate-50/40 -mx-2 px-2 py-1.5 transition-colors" onClick={() => setEditing(true)}>
      <p className={cls}>{block.content || <span className="text-slate-200 italic font-light">Click to edit...</span>}</p>
      <button onClick={e => { e.stopPropagation(); onDelete(); }}
        className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 w-5 h-5 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-300 hover:text-rose-400 shadow-sm transition-all">
        <X className="w-3 h-3" />
      </button>
    </div>
  );
}

export function CenterWorkspace() {
  const { blocks, addBlock, updateBlock, removeBlock, documents, sources, setWormhole, notify } = useWorkspace();
  const [dragOver, setDragOver] = useState(false);
  const [wormholeActive, setWormholeActive] = useState(false);
  const [aiTooltip, setAiTooltip] = useState<{ x: number; y: number; text: string } | null>(null);

  // Update metrics block
  useEffect(() => {
    const metricBlock = blocks.find(b => b.type === 'metric');
    if (metricBlock) {
      const newContent = `Documents|${documents.length}|Sources|${sources.length}|Blocks|${blocks.length}|AI Status|${isReady() ? 'Connected' : 'Offline'}`;
      if (metricBlock.content !== newContent) {
        updateBlock(metricBlock.id, { content: newContent });
      }
    }
  }, [documents.length, sources.length, blocks.length]);

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);

    // External file drop
    if (e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files);
      for (const file of files) {
        const doc = await uploadFile(file, '/');
        if (doc) {
          useWorkspace.getState().addDocument(doc);
          notify(`Uploaded: ${doc.name}`);
        }
      }
      return;
    }

    // Internal drag (wormhole inject)
    const docId = e.dataTransfer.getData('text/plain');
    if (!docId) return;
    const doc = documents.find(d => d.id === docId);
    if (!doc) return;

    setWormholeActive(true);
    setTimeout(() => {
      setWormholeActive(false);
      if (isReady()) {
        const ctx = blocks.filter(b => b.type !== 'ai-stream').map(b => b.content).join('\n').slice(0, 2000);
        const blockId = `ai-${Date.now()}`;
        addBlock({ id: blockId, type: 'ai-stream', content: '', meta: `Wormhole: ${doc.name}`, streaming: true });
        streamPrompt(buildWormholePrompt(doc.name, doc.file_type, ctx),
          (chunk, done) => useWorkspace.getState().updateBlock(blockId, done ? { streaming: false } : { content: useWorkspace.getState().blocks.find(b => b.id === blockId)!.content + chunk }),
          (err) => useWorkspace.getState().updateBlock(blockId, { content: err, streaming: false, error: true })
        );
      } else {
        addBlock({ id: `d${Date.now()}`, type: 'annotation', content: `"${doc.name}" injected via Wormhole. Add API key for AI analysis.` });
      }
    }, 1200);
  };

  const handleTextSelect = () => {
    const sel = window.getSelection();
    const text = sel?.toString().trim();
    if (!text || text.length < 3) { setAiTooltip(null); return; }
    const range = sel!.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    setAiTooltip({ x: rect.left + rect.width / 2, y: rect.top, text });
  };

  const handleAiAction = (action: string, text: string) => {
    if (isReady()) {
      const blockId = `ai-${Date.now()}`;
      addBlock({ id: blockId, type: 'ai-stream', content: '', meta: action, streaming: true });
      streamPrompt(buildAiActionPrompt(action, text),
        (chunk, done) => useWorkspace.getState().updateBlock(blockId, done ? { streaming: false } : { content: useWorkspace.getState().blocks.find(b => b.id === blockId)!.content + chunk }),
        (err) => useWorkspace.getState().updateBlock(blockId, { content: err, streaming: false, error: true })
      );
    } else {
      notify('Add API key in Settings');
    }
    setAiTooltip(null);
  };

  return (
    <div className="h-full flex flex-col bg-white relative">
      {/* Toolbar */}
      <div className="h-10 flex items-center gap-1 px-4 border-b border-slate-100 flex-shrink-0">
        <button onClick={() => addBlock({ id: `d${Date.now()}`, type: 'h3', content: '' })}
          className="p-1.5 rounded-md text-slate-300 hover:text-slate-600 hover:bg-slate-50 transition-colors" title="Heading">
          <Hash className="w-3.5 h-3.5" />
        </button>
        <button onClick={() => addBlock({ id: `d${Date.now()}`, type: 'para', content: '' })}
          className="p-1.5 rounded-md text-slate-300 hover:text-slate-600 hover:bg-slate-50 transition-colors" title="Paragraph">
          <AlignLeft className="w-3.5 h-3.5" />
        </button>
        <button onClick={() => addBlock({ id: `d${Date.now()}`, type: 'data-table', content: 'Element\tConcentration\tUnit\nFe\t45.2\t%\nSiO2\t22.8\t%\nAl2O3\t8.1\t%' })}
          className="p-1.5 rounded-md text-slate-300 hover:text-slate-600 hover:bg-slate-50 transition-colors" title="Table">
          <Table2 className="w-3.5 h-3.5" />
        </button>
        <button onClick={() => setWormhole(true)}
          className="p-1.5 rounded-md text-slate-300 hover:text-teal-600 hover:bg-teal-50 transition-colors" title="Wormhole">
          <Zap className="w-3.5 h-3.5" />
        </button>
        <div className="flex-1" />
        <span className="text-[10px] text-slate-300 font-light">{blocks.length} blocks</span>
      </div>

      {/* Workspace content */}
      <div className={`flex-1 overflow-y-auto relative transition-colors duration-200 ${dragOver ? 'bg-teal-50/10' : ''}`}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onMouseUp={handleTextSelect}>

        {/* Drop overlay */}
        <AnimatePresence>
          {dragOver && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-3 border-2 border-dashed border-teal-200 rounded-2xl z-10 flex items-center justify-center pointer-events-none bg-teal-50/5">
              <div className="flex items-center gap-3 bg-white border border-teal-100 rounded-xl px-6 py-3 shadow-sm">
                <Zap className="w-4 h-4 text-teal-500" />
                <div>
                  <p className="text-[13px] font-medium text-slate-700">Drop to inject via Wormhole</p>
                  <p className="text-[11px] text-teal-500 font-light">Files or documents from Active Memory</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Wormhole loader */}
        <AnimatePresence>
          {wormholeActive && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 z-20 flex items-center justify-center bg-white/80 backdrop-blur-sm">
              <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border border-teal-100 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-teal-500" />
                  </div>
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                    className="absolute inset-0 rounded-full border-2 border-teal-300 border-t-transparent" />
                </div>
                <p className="text-[13px] font-medium text-slate-700">Wormhole active</p>
                <div className="w-40 h-1 bg-slate-100 rounded-full overflow-hidden">
                  <motion.div animate={{ x: ['-100%', '100%'] }} transition={{ duration: 1.2, repeat: Infinity }}
                    className="h-full w-1/2 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full" />
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* AI Tooltip */}
        <AnimatePresence>
          {aiTooltip && (
            <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 4 }}
              className="fixed z-40" style={{ left: Math.max(8, Math.min(aiTooltip.x - 120, window.innerWidth - 320)), top: aiTooltip.y - 52 }}>
              <div className="flex items-center gap-0.5 bg-white border border-slate-200 rounded-xl shadow-lg px-2 py-1.5">
                <div className="flex items-center gap-1.5 mr-2 pr-2 border-r border-slate-100">
                  <Sparkles className="w-3 h-3 text-teal-500" />
                </div>
                {[{ l: 'Rephrase', I: Wand2 }, { l: 'Summarise', I: BookOpen }, { l: 'Extract', I: Target }, { l: 'Translate', I: RotateCcw }].map(a => (
                  <button key={a.l} onMouseDown={e => { e.preventDefault(); handleAiAction(a.l, aiTooltip.text); }}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-50 transition-colors">
                    <a.I className="w-3 h-3 text-slate-500" />
                    <span className="text-[10px] text-slate-600 font-medium">{a.l}</span>
                  </button>
                ))}
                <button onMouseDown={e => { e.preventDefault(); setAiTooltip(null); }}
                  className="ml-1 p-0.5 rounded text-slate-200 hover:text-slate-400"><X className="w-3 h-3" /></button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Blocks */}
        <div className="max-w-2xl mx-auto px-8 py-10 space-y-5">
          {blocks.map(block => (
            <BlockView key={block.id} block={block}
              onEdit={content => updateBlock(block.id, { content })}
              onDelete={() => removeBlock(block.id)} />
          ))}

          {/* Add block */}
          <button onClick={() => { const id = `d${Date.now()}`; addBlock({ id, type: 'para', content: '' }); }}
            className="w-full flex items-center gap-3 py-4 text-slate-200 hover:text-slate-400 transition-colors group">
            <div className="h-px flex-1 bg-slate-100 group-hover:bg-slate-200 transition-colors" />
            <span className="flex items-center gap-1.5 text-[11px] font-medium"><Plus className="w-3 h-3" />Add block</span>
            <div className="h-px flex-1 bg-slate-100 group-hover:bg-slate-200 transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
}
