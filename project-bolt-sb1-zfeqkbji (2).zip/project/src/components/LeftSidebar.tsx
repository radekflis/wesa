import { motion } from 'framer-motion';
import {
  FileText, Folder, ChevronRight, Upload, Plus,
  Trash2, FileSpreadsheet, Image, File,
  Loader2, Check, X, GripVertical,
} from 'lucide-react';
import { useState, useRef } from 'react';
import { useWorkspace } from '../store/workspace';
import { useUploader } from '../lib/hooks';
import { deleteDocument, type DbDocument } from '../supabase';

function fileIcon(type: string) {
  if (type.includes('pdf')) return <FileText className="w-3.5 h-3.5 text-rose-400" />;
  if (type.includes('sheet') || type.includes('excel') || type.includes('csv')) return <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />;
  if (type.includes('image')) return <Image className="w-3.5 h-3.5 text-sky-400" />;
  if (type.includes('geo') || type.includes('json')) return <File className="w-3.5 h-3.5 text-amber-500" />;
  return <FileText className="w-3.5 h-3.5 text-slate-400" />;
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}

export function LeftSidebar() {
  const {
    documents, selectedDocId, selectDocument, removeDocument,
    currentFolder, setCurrentFolder, uploading, notify,
  } = useWorkspace();
  const { inputRef, open, handleFiles, onInputChange } = useUploader();
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const dragRef = useRef<DbDocument | null>(null);

  const folders = Array.from(new Set(documents.map(d => d.folder_path))).sort();
  const currentDocs = currentFolder === '/'
    ? documents
    : documents.filter(d => d.folder_path === currentFolder);

  const handleDelete = async (doc: DbDocument) => {
    const ok = await deleteDocument(doc.id, doc.storage_path);
    if (ok) { removeDocument(doc.id); notify(`Deleted: ${doc.name}`); }
  };

  const createFolder = () => {
    if (!newFolderName.trim()) return;
    const path = currentFolder === '/' ? `/${newFolderName.trim()}` : `${currentFolder}/${newFolderName.trim()}`;
    setCurrentFolder(path);
    setShowNewFolder(false);
    setNewFolderName('');
    notify(`Folder: ${path}`);
  };

  const handleDragStart = (doc: DbDocument) => {
    dragRef.current = doc;
  };

  return (
    <div className="h-full flex flex-col bg-white">
      <input ref={inputRef} type="file" multiple accept="*/*" className="hidden" onChange={onInputChange} />

      {/* Header */}
      <div className="h-11 flex items-center justify-between px-4 border-b border-slate-100 flex-shrink-0">
        <span className="text-[11px] font-semibold text-slate-700 tracking-wide uppercase">Active Memory</span>
        <div className="flex items-center gap-0.5">
          <button onClick={open} className="p-1.5 rounded-md text-slate-400 hover:text-teal-600 hover:bg-teal-50/60 transition-colors" title="Upload">
            <Upload className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setShowNewFolder(true)} className="p-1.5 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors" title="New folder">
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* New folder */}
      {showNewFolder && (
        <div className="px-3 py-2 border-b border-slate-50 flex items-center gap-2 bg-slate-50/50">
          <Folder className="w-3.5 h-3.5 text-amber-400" />
          <input value={newFolderName} onChange={e => setNewFolderName(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') createFolder(); if (e.key === 'Escape') setShowNewFolder(false); }}
            placeholder="Folder name" autoFocus
            className="flex-1 text-[11px] bg-transparent focus:outline-none text-slate-600 placeholder:text-slate-300" />
          <button onClick={createFolder} className="text-emerald-500 hover:text-emerald-600"><Check className="w-3.5 h-3.5" /></button>
          <button onClick={() => setShowNewFolder(false)} className="text-slate-300 hover:text-slate-500"><X className="w-3 h-3" /></button>
        </div>
      )}

      {/* Breadcrumb */}
      <div className="h-8 flex items-center gap-1 px-4 border-b border-slate-50 flex-shrink-0">
        <button onClick={() => setCurrentFolder('/')} className="text-[10px] text-slate-400 hover:text-slate-600 font-medium transition-colors">Root</button>
        {currentFolder !== '/' && currentFolder.split('/').filter(Boolean).map((part, i, arr) => (
          <span key={i} className="flex items-center gap-1">
            <ChevronRight className="w-2.5 h-2.5 text-slate-200" />
            <button onClick={() => setCurrentFolder('/' + arr.slice(0, i + 1).join('/'))}
              className="text-[10px] text-slate-500 hover:text-slate-700 font-medium transition-colors">{part}</button>
          </span>
        ))}
      </div>

      {/* Drop zone */}
      <div className="px-4 py-2 border-b border-slate-50 flex-shrink-0"
        onDragOver={e => e.preventDefault()}
        onDrop={e => { e.preventDefault(); if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); }}>
        <p className="text-[10px] text-slate-300 flex items-center gap-1.5 font-light">
          <GripVertical className="w-3 h-3" />Drop files here or drag to workspace
        </p>
      </div>

      {/* File tree */}
      <div className="flex-1 overflow-y-auto py-1 px-2"
        onDragOver={e => e.preventDefault()}
        onDrop={e => { e.preventDefault(); if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); }}>

        {uploading && (
          <div className="flex items-center gap-2 px-2 py-2 mb-1">
            <Loader2 className="w-3.5 h-3.5 text-teal-500 animate-spin" />
            <span className="text-[11px] text-teal-600 font-medium">Uploading...</span>
          </div>
        )}

        {/* Subfolders */}
        {folders.filter(f => f !== '/' && f !== currentFolder).map(folder => (
          <button key={folder} onClick={() => setCurrentFolder(folder)}
            className="w-full flex items-center gap-2.5 px-2.5 py-[6px] rounded-lg hover:bg-slate-50 transition-colors text-left mb-0.5">
            <Folder className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
            <span className="text-[11px] font-medium text-slate-600 truncate">{folder.split('/').pop()}</span>
          </button>
        ))}

        {/* Files */}
        {currentDocs.map(doc => (
          <motion.div key={doc.id}
            initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.15 }}
            draggable
            onDragStart={() => handleDragStart(doc)}
            onClick={() => selectDocument(doc.id)}
            className={`w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg transition-colors cursor-grab active:cursor-grabbing group mb-0.5 ${
              selectedDocId === doc.id ? 'bg-slate-50 ring-1 ring-slate-200' : 'hover:bg-slate-50/60'
            }`}>
            {fileIcon(doc.file_type)}
            <div className="flex-1 min-w-0">
              <p className="text-[11px] font-medium text-slate-700 truncate leading-tight">{doc.name}</p>
              <p className="text-[9px] text-slate-400 font-light">{formatSize(doc.file_size)}</p>
            </div>
            <button onClick={e => { e.stopPropagation(); handleDelete(doc); }}
              className="opacity-0 group-hover:opacity-100 p-1 rounded text-slate-300 hover:text-rose-400 transition-all">
              <Trash2 className="w-3 h-3" />
            </button>
          </motion.div>
        ))}

        {documents.length === 0 && !uploading && (
          <div className="text-center py-12 px-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 mx-auto flex items-center justify-center mb-3">
              <Upload className="w-5 h-5 text-slate-300" />
            </div>
            <p className="text-[12px] text-slate-500 font-medium">No documents</p>
            <p className="text-[11px] text-slate-300 mt-1 font-light">Upload files to begin</p>
            <button onClick={open}
              className="mt-4 px-4 py-2 bg-slate-900 text-white text-[11px] rounded-lg hover:bg-slate-700 transition-colors font-medium">
              Upload Files
            </button>
          </div>
        )}
      </div>

      {/* Footer stats */}
      <div className="h-8 flex items-center justify-between px-4 border-t border-slate-100 flex-shrink-0 bg-slate-50/30">
        <span className="text-[10px] text-slate-400 font-light">{documents.length} items</span>
        <span className="text-[10px] text-slate-300 font-light">{currentFolder}</span>
      </div>
    </div>
  );
}
