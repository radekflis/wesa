import { motion, AnimatePresence } from 'framer-motion';
import {
  X, Zap, GitMerge, Brain, Layers, Target,
  Network, Scan, RefreshCw,
} from 'lucide-react';
import { useWorkspace } from '../store/workspace';
import { isReady, streamPrompt, buildWormholePrompt } from '../gemini';

const WORMHOLE_ACTIONS = [
  { id: 'map-sources', label: 'Map Sources', desc: 'Link all values to their source documents', icon: Network },
  { id: 'cross-ref', label: 'Cross-Reference', desc: 'Find connections between datasets', icon: GitMerge },
  { id: 'extract', label: 'Extract Data', desc: 'Pull structured data from documents', icon: Scan },
  { id: 'mutate', label: 'Mutate Document', desc: 'Transform and enrich workspace content', icon: RefreshCw },
  { id: 'synthesize', label: 'Synthesize Report', desc: 'Generate comprehensive analysis', icon: Brain },
  { id: 'semantic-link', label: 'Semantic Link', desc: 'Create knowledge graph connections', icon: Layers },
  { id: 'validate', label: 'Validate Sources', desc: 'Check accuracy against references', icon: Target },
];

export function WormholeOverlay() {
  const { wormholeOpen, setWormhole, blocks, addBlock, notify, documents, selectedDocId } = useWorkspace();

  const execute = (actionId: string) => {
    setWormhole(false);
    const action = WORMHOLE_ACTIONS.find(a => a.id === actionId)!;

    if (!isReady()) {
      notify('Add Gemini API key in Settings to use Wormhole');
      return;
    }

    const doc = documents.find(d => d.id === selectedDocId);
    const ctx = blocks.filter(b => b.type !== 'ai-stream').map(b => b.content).join('\n').slice(0, 2000);
    const prompt = buildWormholePrompt(
      doc?.name ?? 'workspace',
      doc?.file_type ?? 'text/plain',
      ctx
    ) + `\n\nAction: ${action.label} - ${action.desc}`;

    const blockId = `ai-${Date.now()}`;
    addBlock({ id: blockId, type: 'ai-stream', content: '', meta: `Wormhole: ${action.label}`, streaming: true });

    streamPrompt(prompt,
      (chunk, done) => useWorkspace.getState().updateBlock(blockId, done ? { streaming: false } : { content: useWorkspace.getState().blocks.find(b => b.id === blockId)!.content + chunk }),
      (err) => useWorkspace.getState().updateBlock(blockId, { content: err, streaming: false, error: true })
    );
  };

  return (
    <AnimatePresence>
      {wormholeOpen && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-center justify-center"
          onClick={() => setWormhole(false)}
        >
          <div className="absolute inset-0 bg-white/60 backdrop-blur-sm" />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-[0_32px_80px_-16px_rgba(0,0,0,0.06)] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 h-14 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-teal-50 to-cyan-50 border border-teal-100 flex items-center justify-center">
                  <Zap className="w-3.5 h-3.5 text-teal-600" />
                </div>
                <div>
                  <p className="text-[13px] font-semibold text-slate-800">Wormhole</p>
                  <p className="text-[10px] text-slate-400 font-light">Contextual AI Operations</p>
                </div>
              </div>
              <button onClick={() => setWormhole(false)} className="p-2 rounded-lg text-slate-300 hover:text-slate-500 hover:bg-slate-50 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Actions */}
            <div className="py-2 max-h-[400px] overflow-y-auto">
              {WORMHOLE_ACTIONS.map(action => (
                <button key={action.id} onClick={() => execute(action.id)}
                  className="w-full flex items-center gap-3.5 px-6 py-3 hover:bg-slate-50 transition-colors text-left group">
                  <div className="w-9 h-9 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:border-teal-200 group-hover:bg-teal-50/50 transition-colors">
                    <action.icon className="w-4 h-4 text-slate-400 group-hover:text-teal-600 transition-colors" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[13px] text-slate-700 font-medium">{action.label}</p>
                    <p className="text-[11px] text-slate-400 font-light">{action.desc}</p>
                  </div>
                </button>
              ))}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/30">
              <p className="text-[10px] text-slate-400 font-light">
                Wormhole connects documents, datasets, and AI models in a semantic pipeline.
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
