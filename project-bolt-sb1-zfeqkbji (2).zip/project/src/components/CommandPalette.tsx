import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, FileText, Sparkles, Globe,
  BarChart2, Map, Database, Cpu, Layers,
} from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { useWorkspace } from '../store/workspace';
import { isReady, streamPrompt, buildSearchPrompt } from '../gemini';

const ACTIONS = [
  { id: 'upload', label: 'Upload Files', desc: 'Add documents to Active Memory', icon: FileText, category: 'File' },
  { id: 'ocr', label: 'OCR Extraction', desc: 'Extract text from images/PDFs', icon: Layers, category: 'Analysis' },
  { id: 'geochem', label: 'Geochemical Analysis', desc: 'Run composition analysis', icon: Globe, category: 'Science' },
  { id: 'valuation', label: 'Resource Valuation', desc: 'Estimate mineral value', icon: BarChart2, category: 'Finance' },
  { id: 'map', label: 'Geographic Mapping', desc: 'Visualize spatial data', icon: Map, category: 'Spatial' },
  { id: 'dataset', label: 'Load Dataset', desc: 'Import structured data', icon: Database, category: 'Data' },
  { id: 'ai-workflow', label: 'AI Workflow', desc: 'Spawn contextual AI process', icon: Cpu, category: 'AI' },
  { id: 'wormhole', label: 'Wormhole Inject', desc: 'Cross-reference and mutate', icon: Sparkles, category: 'AI' },
];

export function CommandPalette() {
  const { commandPaletteOpen, setCommandPalette, blocks, addBlock, notify, setWormhole } = useWorkspace();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (commandPaletteOpen) { setQuery(''); setTimeout(() => inputRef.current?.focus(), 50); }
  }, [commandPaletteOpen]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setCommandPalette(!commandPaletteOpen); }
      if (e.key === 'Escape') setCommandPalette(false);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [commandPaletteOpen, setCommandPalette]);

  const filtered = ACTIONS.filter(a =>
    a.label.toLowerCase().includes(query.toLowerCase()) ||
    a.desc.toLowerCase().includes(query.toLowerCase()) ||
    a.category.toLowerCase().includes(query.toLowerCase())
  );

  const execute = (id: string) => {
    setCommandPalette(false);
    switch (id) {
      case 'wormhole': setWormhole(true); break;
      case 'ai-workflow':
        if (isReady()) {
          const blockId = `ai-${Date.now()}`;
          addBlock({ id: blockId, type: 'ai-stream', content: '', meta: 'AI Workflow', streaming: true });
          const ctx = blocks.filter(b => b.type !== 'ai-stream').map(b => b.content).join('\n').slice(0, 2000);
          streamPrompt(
            buildSearchPrompt('Analyze workspace and suggest next actions', ctx),
            (chunk, done) => useWorkspace.getState().updateBlock(blockId, done ? { streaming: false } : { content: useWorkspace.getState().blocks.find(b => b.id === blockId)!.content + chunk }),
            (err) => useWorkspace.getState().updateBlock(blockId, { content: err, streaming: false, error: true })
          );
        } else { notify('Add Gemini API key in Settings'); }
        break;
      default: notify(`Action: ${ACTIONS.find(a => a.id === id)?.label}`); break;
    }
  };

  const handleSubmit = () => {
    if (query.trim() && isReady()) {
      setCommandPalette(false);
      const blockId = `ai-${Date.now()}`;
      const store = useWorkspace.getState();
      store.addBlock({ id: blockId, type: 'ai-stream', content: '', meta: `Search: "${query}"`, streaming: true });
      const ctx = store.blocks.filter(b => b.type !== 'ai-stream').map(b => b.content).join('\n').slice(0, 2000);
      streamPrompt(
        buildSearchPrompt(query, ctx),
        (chunk, done) => useWorkspace.getState().updateBlock(blockId, done ? { streaming: false } : { content: useWorkspace.getState().blocks.find(b => b.id === blockId)!.content + chunk }),
        (err) => useWorkspace.getState().updateBlock(blockId, { content: err, streaming: false, error: true })
      );
    } else if (filtered.length > 0) {
      execute(filtered[0].id);
    }
  };

  return (
    <AnimatePresence>
      {commandPaletteOpen && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[12vh]"
          onClick={() => setCommandPalette(false)}
        >
          <div className="absolute inset-0 bg-slate-900/5 backdrop-blur-[2px]" />
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.15 }}
            className="relative w-full max-w-[560px] bg-white border border-slate-200 rounded-2xl shadow-[0_24px_80px_-12px_rgba(0,0,0,0.08)] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 px-5 h-14 border-b border-slate-100">
              <Search className="w-4 h-4 text-slate-300" />
              <input
                ref={inputRef}
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSubmit(); }}
                placeholder="Search actions, documents, or ask AI..."
                className="flex-1 text-[15px] text-slate-800 placeholder:text-slate-300 focus:outline-none font-light"
              />
              <kbd className="text-[10px] text-slate-300 bg-slate-50 border border-slate-100 px-1.5 py-0.5 rounded font-mono">ESC</kbd>
            </div>
            <div className="max-h-[320px] overflow-y-auto py-2">
              {filtered.map(action => (
                <button key={action.id} onClick={() => execute(action.id)}
                  className="w-full flex items-center gap-3.5 px-5 py-2.5 hover:bg-slate-50 transition-colors text-left group">
                  <div className="w-8 h-8 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:border-slate-200 transition-colors">
                    <action.icon className="w-3.5 h-3.5 text-slate-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] text-slate-700 font-medium">{action.label}</p>
                    <p className="text-[11px] text-slate-400 font-light">{action.desc}</p>
                  </div>
                  <span className="text-[10px] text-slate-300 font-light">{action.category}</span>
                </button>
              ))}
              {filtered.length === 0 && query && (
                <div className="px-5 py-6 text-center">
                  <p className="text-[13px] text-slate-400">Press Enter to search with AI</p>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
