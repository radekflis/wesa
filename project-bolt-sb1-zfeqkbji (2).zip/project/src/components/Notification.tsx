import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, X } from 'lucide-react';
import { useWorkspace } from '../store/workspace';

export function Notification() {
  const { notification } = useWorkspace();

  return (
    <AnimatePresence>
      {notification && (
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.2 }}
          className="fixed top-4 left-1/2 -translate-x-1/2 z-[200] flex items-center gap-3 bg-white border border-slate-200 rounded-xl shadow-[0_8px_32px_-8px_rgba(0,0,0,0.06)] px-5 py-3"
        >
          <CheckCircle2 className="w-4 h-4 text-teal-500 flex-shrink-0" />
          <p className="text-[13px] font-medium text-slate-700">{notification}</p>
          <button onClick={() => useWorkspace.setState({ notification: '' })} className="p-1 rounded text-slate-300 hover:text-slate-500 transition-colors">
            <X className="w-3.5 h-3.5" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
