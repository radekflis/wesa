import { motion, AnimatePresence } from 'framer-motion';
import { X, Key, Settings as SettingsIcon, CheckCircle2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useWorkspace } from '../store/workspace';
import { initGemini, isReady } from '../gemini';

const LS_KEY = 'alaw_gemini_key';

export function SettingsModal() {
  const { settingsOpen, setSettings, notify } = useWorkspace();
  const [apiKey, setApiKey] = useState(() => localStorage.getItem(LS_KEY) ?? import.meta.env.VITE_GEMINI_API_KEY ?? '');

  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setSettings(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSettings]);

  const handleSave = () => {
    if (apiKey) localStorage.setItem(LS_KEY, apiKey);
    else localStorage.removeItem(LS_KEY);
    initGemini(apiKey);
    setSettings(false);
    notify('Settings saved');
  };

  return (
    <AnimatePresence>
      {settingsOpen && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center"
          onClick={() => setSettings(false)}
        >
          <div className="absolute inset-0 bg-slate-900/5 backdrop-blur-[2px]" />
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.15 }}
            className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-[0_24px_80px_-12px_rgba(0,0,0,0.08)] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 h-14 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <SettingsIcon className="w-4 h-4 text-slate-500" />
                <span className="text-[14px] font-semibold text-slate-800">Settings</span>
              </div>
              <button onClick={() => setSettings(false)} className="p-2 rounded-lg text-slate-300 hover:text-slate-500 transition-colors"><X className="w-4 h-4" /></button>
            </div>
            <div className="px-6 py-6 space-y-5">
              <div>
                <label className="text-[12px] font-semibold text-slate-700 mb-2 flex items-center gap-2">
                  <Key className="w-3.5 h-3.5 text-slate-400" />Gemini API Key
                </label>
                <input type="password" value={apiKey} onChange={e => setApiKey(e.target.value)}
                  placeholder="Enter API key..."
                  className="w-full mt-2 px-4 py-2.5 text-[13px] bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-300 font-mono placeholder:text-slate-300" />
                <p className="text-[11px] text-slate-400 mt-2 font-light">Required for AI features. Key is stored locally.</p>
              </div>

              {isReady() && (
                <div className="flex items-center gap-2 bg-emerald-50/60 border border-emerald-100 rounded-xl px-4 py-2.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-[12px] text-emerald-700 font-medium">AI Connected</span>
                </div>
              )}

              <button onClick={handleSave}
                className="w-full py-2.5 bg-slate-900 text-white text-[13px] rounded-xl font-medium hover:bg-slate-700 transition-colors">
                Save Settings
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
