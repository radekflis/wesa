import { create } from 'zustand';
import type { DbDocument, DbSource } from '../supabase';

export interface WorkspaceTab {
  id: string;
  label: string;
  type: 'document' | 'analysis' | 'map' | 'dataset' | 'report';
  documentId?: string;
  active: boolean;
}

export interface DocBlock {
  id: string;
  type: 'h1' | 'h2' | 'h3' | 'para' | 'metric' | 'data-table' | 'annotation' | 'ai-stream' | 'source-ref';
  content: string;
  meta?: string;
  sourceId?: string;
  streaming?: boolean;
  error?: boolean;
}

export interface WorkspaceState {
  // Panels
  leftOpen: boolean;
  rightOpen: boolean;
  toggleLeft: () => void;
  toggleRight: () => void;

  // Tabs
  tabs: WorkspaceTab[];
  activeTabId: string;
  addTab: (tab: Omit<WorkspaceTab, 'active'>) => void;
  closeTab: (id: string) => void;
  setActiveTab: (id: string) => void;

  // Documents
  documents: DbDocument[];
  setDocuments: (docs: DbDocument[]) => void;
  addDocument: (doc: DbDocument) => void;
  removeDocument: (id: string) => void;
  selectedDocId: string | null;
  selectDocument: (id: string | null) => void;

  // Sources
  sources: DbSource[];
  setSources: (sources: DbSource[]) => void;
  addSourceEntry: (source: DbSource) => void;

  // Blocks
  blocks: DocBlock[];
  setBlocks: (blocks: DocBlock[]) => void;
  addBlock: (block: DocBlock) => void;
  updateBlock: (id: string, updates: Partial<DocBlock>) => void;
  removeBlock: (id: string) => void;

  // Workspace state
  currentFolder: string;
  setCurrentFolder: (path: string) => void;
  uploading: boolean;
  setUploading: (v: boolean) => void;
  synced: boolean;
  setSynced: (v: boolean) => void;

  // Modals
  commandPaletteOpen: boolean;
  setCommandPalette: (v: boolean) => void;
  wormholeOpen: boolean;
  setWormhole: (v: boolean) => void;
  settingsOpen: boolean;
  setSettings: (v: boolean) => void;

  // Notification
  notification: string;
  notify: (msg: string) => void;
}

export const useWorkspace = create<WorkspaceState>((set) => ({
  leftOpen: true,
  rightOpen: true,
  toggleLeft: () => set(s => ({ leftOpen: !s.leftOpen })),
  toggleRight: () => set(s => ({ rightOpen: !s.rightOpen })),

  tabs: [
    { id: 'main', label: 'Workspace', type: 'document', active: true },
  ],
  activeTabId: 'main',
  addTab: (tab) => set(s => ({
    tabs: [...s.tabs.map(t => ({ ...t, active: false })), { ...tab, active: true }],
    activeTabId: tab.id,
  })),
  closeTab: (id) => set(s => {
    if (s.tabs.length <= 1) return s;
    const filtered = s.tabs.filter(t => t.id !== id);
    const wasActive = s.activeTabId === id;
    if (wasActive) {
      filtered[filtered.length - 1].active = true;
      return { tabs: filtered, activeTabId: filtered[filtered.length - 1].id };
    }
    return { tabs: filtered };
  }),
  setActiveTab: (id) => set(s => ({
    tabs: s.tabs.map(t => ({ ...t, active: t.id === id })),
    activeTabId: id,
  })),

  documents: [],
  setDocuments: (docs) => set({ documents: docs }),
  addDocument: (doc) => set(s => ({ documents: [doc, ...s.documents] })),
  removeDocument: (id) => set(s => ({
    documents: s.documents.filter(d => d.id !== id),
    selectedDocId: s.selectedDocId === id ? null : s.selectedDocId,
  })),
  selectedDocId: null,
  selectDocument: (id) => set({ selectedDocId: id }),

  sources: [],
  setSources: (sources) => set({ sources }),
  addSourceEntry: (source) => set(s => ({ sources: [source, ...s.sources] })),

  blocks: [
    { id: 'b1', type: 'h1', content: 'Adaptive Layered AI Workflowstation' },
    { id: 'b2', type: 'h2', content: 'OPERATIONAL WORKSPACE' },
    { id: 'b3', type: 'para', content: 'This workspace connects documents, datasets, geographic data, mineral compositions, and AI workflows into a unified semantic environment. Upload files to the Active Memory panel, then drag them onto this workspace to inject via Wormhole.' },
    { id: 'b4', type: 'metric', content: 'Documents|0|Sources|0|Blocks|4|AI Status|Connected' },
  ],
  setBlocks: (blocks) => set({ blocks }),
  addBlock: (block) => set(s => ({ blocks: [...s.blocks, block] })),
  updateBlock: (id, updates) => set(s => ({
    blocks: s.blocks.map(b => b.id === id ? { ...b, ...updates } : b),
  })),
  removeBlock: (id) => set(s => ({ blocks: s.blocks.filter(b => b.id !== id) })),

  currentFolder: '/',
  setCurrentFolder: (path) => set({ currentFolder: path }),
  uploading: false,
  setUploading: (v) => set({ uploading: v }),
  synced: true,
  setSynced: (v) => set({ synced: v }),

  commandPaletteOpen: false,
  setCommandPalette: (v) => set({ commandPaletteOpen: v }),
  wormholeOpen: false,
  setWormhole: (v) => set({ wormholeOpen: v }),
  settingsOpen: false,
  setSettings: (v) => set({ settingsOpen: v }),

  notification: '',
  notify: (msg) => {
    set({ notification: msg });
    setTimeout(() => set({ notification: '' }), 4000);
  },
}));
