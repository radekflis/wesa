/*
# Create documents and knowledge base tables

1. New Tables
  - `documents` - Uploaded files and their metadata
    - `id` (uuid, primary key)
    - `name` (text, file name)
    - `file_type` (text, mime type)
    - `file_size` (bigint, bytes)
    - `folder_path` (text, virtual folder path)
    - `storage_path` (text, path in Supabase storage)
    - `content_text` (text, extracted text content for search)
    - `tags` (text array, for categorization)
    - `created_at` (timestamp)
    - `updated_at` (timestamp)

  - `sources` - Knowledge base entries linked to document content
    - `id` (uuid, primary key)
    - `document_id` (uuid, FK to documents)
    - `label` (text, the word/value/object being sourced)
    - `source_text` (text, the source reference description)
    - `source_url` (text, optional URL)
    - `page_number` (integer, optional page ref)
    - `confidence` (integer, 0-100)
    - `verified` (boolean)
    - `created_at` (timestamp)

  - `workspace_blocks` - Document workspace content blocks
    - `id` (uuid, primary key)
    - `document_id` (uuid, FK to documents, nullable for standalone blocks)
    - `block_type` (text)
    - `content` (text)
    - `meta` (text)
    - `source_id` (uuid, FK to sources, nullable)
    - `position` (integer, ordering)
    - `created_at` (timestamp)

2. Security
  - Enable RLS on all tables.
  - Allow anon + authenticated full CRUD (single-tenant, no auth).

3. Notes
  - Single-tenant design - no user_id columns.
  - All data is intentionally shared/public within the workspace.
*/

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  file_type text NOT NULL DEFAULT 'application/octet-stream',
  file_size bigint NOT NULL DEFAULT 0,
  folder_path text NOT NULL DEFAULT '/',
  storage_path text,
  content_text text DEFAULT '',
  tags text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_documents" ON documents;
CREATE POLICY "anon_select_documents" ON documents FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_documents" ON documents;
CREATE POLICY "anon_insert_documents" ON documents FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_documents" ON documents;
CREATE POLICY "anon_update_documents" ON documents FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_documents" ON documents;
CREATE POLICY "anon_delete_documents" ON documents FOR DELETE
  TO anon, authenticated USING (true);

-- Sources table
CREATE TABLE IF NOT EXISTS sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid REFERENCES documents(id) ON DELETE CASCADE,
  label text NOT NULL,
  source_text text NOT NULL DEFAULT '',
  source_url text,
  page_number integer,
  confidence integer DEFAULT 0,
  verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sources ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sources" ON sources;
CREATE POLICY "anon_select_sources" ON sources FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sources" ON sources;
CREATE POLICY "anon_insert_sources" ON sources FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sources" ON sources;
CREATE POLICY "anon_update_sources" ON sources FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sources" ON sources;
CREATE POLICY "anon_delete_sources" ON sources FOR DELETE
  TO anon, authenticated USING (true);

-- Workspace blocks table
CREATE TABLE IF NOT EXISTS workspace_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid REFERENCES documents(id) ON DELETE SET NULL,
  block_type text NOT NULL DEFAULT 'para',
  content text NOT NULL DEFAULT '',
  meta text,
  source_id uuid REFERENCES sources(id) ON DELETE SET NULL,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE workspace_blocks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_workspace_blocks" ON workspace_blocks;
CREATE POLICY "anon_select_workspace_blocks" ON workspace_blocks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_workspace_blocks" ON workspace_blocks;
CREATE POLICY "anon_insert_workspace_blocks" ON workspace_blocks FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_workspace_blocks" ON workspace_blocks;
CREATE POLICY "anon_update_workspace_blocks" ON workspace_blocks FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_workspace_blocks" ON workspace_blocks;
CREATE POLICY "anon_delete_workspace_blocks" ON workspace_blocks FOR DELETE
  TO anon, authenticated USING (true);
