/*
# Fix storage policies - add UPDATE policy

The upload process sometimes needs UPDATE access for multipart uploads.
Adding the missing UPDATE policy for the documents bucket.
*/

DROP POLICY IF EXISTS "anon_update_documents_storage" ON storage.objects;
CREATE POLICY "anon_update_documents_storage" ON storage.objects FOR UPDATE
  TO anon, authenticated USING (bucket_id = 'documents') WITH CHECK (bucket_id = 'documents');
