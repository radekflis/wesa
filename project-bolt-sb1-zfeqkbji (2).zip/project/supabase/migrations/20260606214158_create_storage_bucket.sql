/*
# Create storage bucket for document uploads

1. Storage
  - Creates `documents` bucket for file uploads
  - Public access for reading (files served directly)
  - Allows any file type upload

2. Security
  - RLS policies allow anon + authenticated to upload, read, and delete files
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('documents', 'documents', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "anon_upload_documents" ON storage.objects;
CREATE POLICY "anon_upload_documents" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'documents');

DROP POLICY IF EXISTS "anon_read_documents" ON storage.objects;
CREATE POLICY "anon_read_documents" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'documents');

DROP POLICY IF EXISTS "anon_delete_documents" ON storage.objects;
CREATE POLICY "anon_delete_documents" ON storage.objects FOR DELETE
  TO anon, authenticated USING (bucket_id = 'documents');
